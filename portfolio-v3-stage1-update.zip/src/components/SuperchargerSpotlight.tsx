"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { SuperchargerModel } from "./SuperchargerModel";
import styles from "./SuperchargerSpotlight.module.css";

export function SuperchargerSpotlight() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const modelY = useTransform(scrollYProgress, [0, 1], [28, -28]);
  const copyY = useTransform(scrollYProgress, [0, 1], [18, -24]);

  return (
    <section className={styles.section} id="supercharger" ref={sectionRef}>
      <div className={`${styles.grid} section-shell`}>
        <motion.div
          className={styles.copy}
          style={reduceMotion ? undefined : { y: copyY }}
          initial={reduceMotion ? false : { opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, amount: 0.35 }}
          transition={{ duration: 0.8 }}
        >
          <p className="project-label">02 / Mechanical assembly</p>
          <h2>Roots supercharger</h2>
          <div className={styles.statement}>
            <span>Component-level CAD.</span>
            <span>Interactive assembly.</span>
          </div>
          <p className={styles.summary}>
            A full mechanical assembly developed to study twin-rotor packaging, timing-drive layout,
            bearing support, sealing, and serviceable component architecture.
          </p>
          <div className={styles.meta}>
            <span>Onshape</span>
            <span>Assembly design</span>
            <span>2026</span>
          </div>
        </motion.div>

        <motion.div className={styles.viewer} style={reduceMotion ? undefined : { y: modelY }}>
          <SuperchargerModel modelScale={0.94} />
        </motion.div>
      </div>

      <div className={`${styles.scope} section-shell`} aria-label="Supercharger assembly scope">
        <span>02</span>
        <span>Housing</span>
        <span>Rotor pack</span>
        <span>Timing drive</span>
        <span>Snout</span>
      </div>
    </section>
  );
}
