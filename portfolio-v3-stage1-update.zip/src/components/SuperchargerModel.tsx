"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

type SuperchargerModelProps = {
  src?: string;
  label?: string;
  className?: string;
  autoRotate?: boolean;
  modelScale?: number;
};

export function SuperchargerModel({
  src = "/models/supercharger.glb",
  label = "Interactive Roots supercharger assembly",
  className = "",
  autoRotate = true,
  modelScale = 1,
}: SuperchargerModelProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    setLoaded(false);
    setFailed(false);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);
    camera.position.set(0, 0.02, 2.35);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;
    mount.appendChild(renderer.domElement);

    const ambient = new THREE.HemisphereLight(0xffffff, 0x0c0c0c, 1.5);
    scene.add(ambient);

    const key = new THREE.DirectionalLight(0xffffff, 4.4);
    key.position.set(3.2, 4.1, 5.2);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0xbfc6d2, 2.7);
    rim.position.set(-4.1, 1.6, -3.2);
    scene.add(rim);

    const fill = new THREE.DirectionalLight(0xffffff, 1.55);
    fill.position.set(0.2, -3.8, 2.4);
    scene.add(fill);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.065;
    controls.enablePan = false;
    controls.enableZoom = true;
    controls.minDistance = 1.2;
    controls.maxDistance = 4.2;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 0.48;

    let model: THREE.Object3D | null = null;
    let frame = 0;
    let disposed = false;

    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color("#bebeba"),
      metalness: 0.74,
      roughness: 0.36,
      side: THREE.DoubleSide,
    });

    const loader = new GLTFLoader();
    loader.load(
      src,
      (gltf) => {
        if (disposed) return;

        model = gltf.scene;
        model.traverse((child) => {
          if (!(child instanceof THREE.Mesh)) return;
          child.material = bodyMaterial;
          child.castShadow = false;
          child.receiveShadow = false;
        });

        const rawBounds = new THREE.Box3().setFromObject(model);
        const rawCenter = rawBounds.getCenter(new THREE.Vector3());
        model.position.sub(rawCenter);

        // Match the same presentation logic used for the wheel: orient first,
        // then recenter from the final world-space bounds before scaling.
        model.rotation.set(-0.34, 0.42, -Math.PI / 2 + 0.14);

        const rotatedBounds = new THREE.Box3().setFromObject(model);
        const rotatedCenter = rotatedBounds.getCenter(new THREE.Vector3());
        model.position.sub(rotatedCenter);

        const centeredBounds = new THREE.Box3().setFromObject(model);
        const size = centeredBounds.getSize(new THREE.Vector3());
        const maxDimension = Math.max(size.x, size.y, size.z) || 1;
        const targetSize = 1.48 * modelScale;
        model.scale.setScalar(targetSize / maxDimension);

        scene.add(model);
        controls.target.set(0, 0, 0);
        controls.update();
        setLoaded(true);
      },
      undefined,
      (error) => {
        console.error("Supercharger model failed to load:", src, error);
        if (!disposed) setFailed(true);
      },
    );

    const stopAutoRotate = () => {
      controls.autoRotate = false;
    };
    renderer.domElement.addEventListener("pointerdown", stopAutoRotate, { once: true });

    const resize = () => {
      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();
    requestAnimationFrame(resize);

    const animate = () => {
      if (disposed) return;
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", stopAutoRotate);
      bodyMaterial.dispose();
      renderer.dispose();
      renderer.domElement.remove();
      model?.traverse((child) => {
        if (child instanceof THREE.Mesh) child.geometry?.dispose();
      });
    };
  }, [src, autoRotate, modelScale]);

  return (
    <div
      className={`supercharger-model ${className}`}
      ref={mountRef}
      role="img"
      aria-label={label}
    >
      {!loaded && !failed && <span className="supercharger-status">Loading 3D assembly</span>}
      {failed && <span className="supercharger-status">3D assembly unavailable</span>}
      <span className="supercharger-interaction-hint">Drag to rotate · Scroll to zoom</span>
    </div>
  );
}
