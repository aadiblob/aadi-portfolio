"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

type SuperchargerModelProps = {
  src?: string;
  label?: string;
  className?: string;
  autoRotate?: boolean;
  modelScale?: number;
};

type MaterialRole = "housing" | "gold" | "accessory" | "drive" | "hardware";

function getSourceColor(source: THREE.MeshStandardMaterial): THREE.Color {
  return source.color.clone();
}

function classifyMaterial(source: THREE.MeshStandardMaterial): MaterialRole {
  const color = getSourceColor(source);
  const { h, s, l } = color.getHSL({ h: 0, s: 0, l: 0 });

  // Onshape exports the rotors and selected shafts as a saturated gold.
  if (s > 0.34 && h > 0.08 && h < 0.18) return "gold";

  // The source model already contains several grayscale material levels.
  // Preserve that hierarchy while replacing the blown-out white appearance.
  if (l >= 0.84) return "housing";
  if (l >= 0.67) return "accessory";
  if (l >= 0.5) return "hardware";
  return "drive";
}

function createPresentationMaterial(source: THREE.Material): THREE.Material {
  if (!(source instanceof THREE.MeshStandardMaterial)) {
    const fallback = source.clone();
    fallback.side = THREE.DoubleSide;
    return fallback;
  }

  const role = classifyMaterial(source);
  const material = source.clone();

  material.side = THREE.DoubleSide;
  material.transparent = false;
  material.opacity = 1;
  material.emissive.set(0x000000);
  material.emissiveIntensity = 0;

  switch (role) {
    case "gold":
      material.color.set("#d39b16");
      material.metalness = 0.58;
      material.roughness = 0.34;
      material.envMapIntensity = 0.55;
      break;

    case "housing":
      // Match the restrained metallic finish used by the wheel viewer rather
      // than rendering the casing as a flat white plastic shell.
      material.color.set("#a9afb3");
      material.metalness = 0.76;
      material.roughness = 0.4;
      material.envMapIntensity = 0.7;
      break;

    case "accessory":
      material.color.set("#666d72");
      material.metalness = 0.72;
      material.roughness = 0.38;
      material.envMapIntensity = 0.62;
      break;

    case "hardware":
      material.color.set("#444a4f");
      material.metalness = 0.68;
      material.roughness = 0.4;
      material.envMapIntensity = 0.56;
      break;

    case "drive":
      // Timing gears, pulley/belt-drive pieces, and the darkest accessories.
      material.color.set("#23282c");
      material.metalness = 0.62;
      material.roughness = 0.44;
      material.envMapIntensity = 0.48;
      break;
  }

  material.needsUpdate = true;
  return material;
}

export function SuperchargerModel({
  src = "/models/supercharger.glb",
  label = "Interactive Roots supercharger assembly",
  className = "",
  autoRotate = true,
  modelScale = 1,
}: SuperchargerModelProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    setLoaded(false);
    setFailed(false);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);
    // Start from a conventional three-quarter engineering view. The GLB axis
    // correction below makes world Y the actual vertical direction of the assembly.
    camera.position.set(0, 0.96, 2.58);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.96;
    mount.appendChild(renderer.domElement);

    // Reuse the proven wheel-lighting balance. The lower exposure and controlled
    // fills retain machined highlights without washing the housing to pure white.
    const hemisphere = new THREE.HemisphereLight(0xffffff, 0x101214, 1.35);
    scene.add(hemisphere);

    const key = new THREE.DirectionalLight(0xffffff, 3.8);
    key.position.set(3.2, 4.1, 5.2);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0xc3ccd6, 2.25);
    rim.position.set(-4.1, 1.6, -3.2);
    scene.add(rim);

    const fill = new THREE.DirectionalLight(0xf1f3f5, 1.15);
    fill.position.set(0.2, -3.8, 2.4);
    scene.add(fill);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.09;
    controls.enablePan = false;
    controls.enableZoom = true;
    controls.minDistance = 1.2;
    controls.maxDistance = 4.2;

    // Treat the assembly like it is sitting on a turntable instead of floating
    // freely in space. Horizontal rotation remains a full 360 degrees, while
    // vertical movement is limited to a useful engineering-view range so the
    // model cannot flip upside down or become disorienting.
    controls.minPolarAngle = Math.PI * 0.23;
    controls.maxPolarAngle = Math.PI * 0.68;
    controls.rotateSpeed = 0.42;
    controls.zoomSpeed = 0.72;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 0.38;

    let model: THREE.Object3D | null = null;
    let frame = 0;
    let disposed = false;
    const ownedMaterials = new Set<THREE.Material>();

    const loader = new GLTFLoader();
    loader.load(
      src,
      (gltf) => {
        if (disposed) return;

        model = gltf.scene;
        model.traverse((child) => {
          if (!(child instanceof THREE.Mesh)) return;

          if (Array.isArray(child.material)) {
            child.material = child.material.map((sourceMaterial) => {
              const material = createPresentationMaterial(sourceMaterial);
              ownedMaterials.add(material);
              return material;
            });
          } else {
            const material = createPresentationMaterial(child.material);
            ownedMaterials.add(material);
            child.material = material;
          }

          child.castShadow = false;
          child.receiveShadow = false;
        });

        const importedModel = model;
        const rawBounds = new THREE.Box3().setFromObject(importedModel);
        const rawCenter = rawBounds.getCenter(new THREE.Vector3());
        importedModel.position.sub(rawCenter);

        // The Onshape assembly was exported with its longitudinal axis on local Y
        // and its physical vertical direction on local Z. OrbitControls assumes
        // world Y is vertical, so the old freehand Euler rotation made the
        // turntable orbit around the wrong axis. This basis remap fixes that once:
        //   local X (assembly width)  -> world Z
        //   local Y (assembly length) -> world X
        //   local Z (assembly up)     -> world Y
        const axisFrame = new THREE.Group();
        axisFrame.name = "supercharger-axis-correction";
        axisFrame.add(importedModel);

        const axisMatrix = new THREE.Matrix4().makeBasis(
          new THREE.Vector3(0, 0, 1),
          new THREE.Vector3(1, 0, 0),
          new THREE.Vector3(0, 1, 0),
        );
        axisFrame.quaternion.setFromRotationMatrix(axisMatrix);

        // Keep the assembly upright, then add only a world-Y yaw for the hero
        // three-quarter view. Because this yaw uses the corrected vertical axis,
        // horizontal dragging now behaves like a real display turntable.
        const presentationFrame = new THREE.Group();
        presentationFrame.name = "supercharger-presentation-frame";
        presentationFrame.rotation.y = -0.5;
        presentationFrame.add(axisFrame);

        const orientedBounds = new THREE.Box3().setFromObject(presentationFrame);
        const orientedCenter = orientedBounds.getCenter(new THREE.Vector3());
        presentationFrame.position.sub(orientedCenter);

        const centeredBounds = new THREE.Box3().setFromObject(presentationFrame);
        const size = centeredBounds.getSize(new THREE.Vector3());
        const maxDimension = Math.max(size.x, size.y, size.z) || 1;
        const targetSize = 1.48 * modelScale;
        presentationFrame.scale.setScalar(targetSize / maxDimension);

        model = presentationFrame;
        scene.add(model);
        controls.target.set(0, 0, 0);
        controls.update();
        controls.saveState();
        setLoaded(true);
      },
      undefined,
      (error) => {
        console.error("Supercharger model failed to load:", src, error);
        if (!disposed) setFailed(true);
      },
    );

    const stopAutoRotate = () => {
      controls.autoRotate = false;
    };

    const resetView = () => {
      controls.autoRotate = false;
      controls.reset();
      controls.update();
    };

    renderer.domElement.addEventListener("pointerdown", stopAutoRotate, { once: true });
    renderer.domElement.addEventListener("dblclick", resetView);

    const resize = () => {
      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();
    requestAnimationFrame(resize);

    const animate = () => {
      if (disposed) return;
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", stopAutoRotate);
      renderer.domElement.removeEventListener("dblclick", resetView);
      ownedMaterials.forEach((material) => material.dispose());
      renderer.dispose();
      renderer.domElement.remove();
      model?.traverse((child) => {
        if (child instanceof THREE.Mesh) child.geometry?.dispose();
      });
    };
  }, [src, autoRotate, modelScale]);

  return (
    <div
      className={`supercharger-model ${className}`}
      ref={mountRef}
      role="img"
      aria-label={label}
    >
      {!loaded && !failed && <span className="supercharger-status">Loading 3D assembly</span>}
      {failed && <span className="supercharger-status">3D assembly unavailable</span>}
      <span className="supercharger-interaction-hint">Drag to rotate · Scroll to zoom · Double-click to reset</span>
    </div>
  );
}
