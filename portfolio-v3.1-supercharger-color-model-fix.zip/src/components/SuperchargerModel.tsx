"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

type SuperchargerModelProps = {
  src?: string;
  label?: string;
  className?: string;
  autoRotate?: boolean;
  modelScale?: number;
};

function prepareMaterial(source: THREE.Material): THREE.Material {
  const material = source.clone();

  // Keep the colors exported from Onshape, but make the finish readable against
  // the black portfolio background. A highly metallic material without an HDR
  // environment reflects mostly black, which caused the silhouette in V3.0.
  if (material instanceof THREE.MeshStandardMaterial) {
    material.side = THREE.DoubleSide;
    material.metalness = Math.min(material.metalness, 0.16);
    material.roughness = 0.5;
    material.envMapIntensity = 0.35;

    // A tiny amount of color-matched fill keeps dark-facing surfaces legible
    // without flattening the directional highlights.
    material.emissive.copy(material.color).multiplyScalar(0.035);
    material.emissiveIntensity = 1;
    material.needsUpdate = true;
  }

  return material;
}

export function SuperchargerModel({
  src = "/models/supercharger.glb",
  label = "Interactive Roots supercharger assembly",
  className = "",
  autoRotate = true,
  modelScale = 1,
}: SuperchargerModelProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    setLoaded(false);
    setFailed(false);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);
    camera.position.set(0, 0.02, 2.35);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.24;
    mount.appendChild(renderer.domElement);

    // Broad fill guarantees that every exported Onshape color remains visible.
    const ambient = new THREE.AmbientLight(0xffffff, 1.15);
    scene.add(ambient);

    const hemisphere = new THREE.HemisphereLight(0xffffff, 0x343434, 1.85);
    scene.add(hemisphere);

    const key = new THREE.DirectionalLight(0xffffff, 3.5);
    key.position.set(3.2, 4.1, 5.2);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0xd9e2f0, 2.45);
    rim.position.set(-4.1, 1.6, -3.2);
    scene.add(rim);

    const fill = new THREE.DirectionalLight(0xfff4e4, 1.85);
    fill.position.set(0.2, -3.8, 2.4);
    scene.add(fill);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.065;
    controls.enablePan = false;
    controls.enableZoom = true;
    controls.minDistance = 1.2;
    controls.maxDistance = 4.2;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 0.48;

    let model: THREE.Object3D | null = null;
    let frame = 0;
    let disposed = false;
    const ownedMaterials = new Set<THREE.Material>();

    const loader = new GLTFLoader();
    loader.load(
      src,
      (gltf) => {
        if (disposed) return;

        model = gltf.scene;
        model.traverse((child) => {
          if (!(child instanceof THREE.Mesh)) return;

          if (Array.isArray(child.material)) {
            child.material = child.material.map((sourceMaterial) => {
              const material = prepareMaterial(sourceMaterial);
              ownedMaterials.add(material);
              return material;
            });
          } else {
            const material = prepareMaterial(child.material);
            ownedMaterials.add(material);
            child.material = material;
          }

          child.castShadow = false;
          child.receiveShadow = false;
        });

        const rawBounds = new THREE.Box3().setFromObject(model);
        const rawCenter = rawBounds.getCenter(new THREE.Vector3());
        model.position.sub(rawCenter);

        // Use the same proven wheel-viewer sequence: orient, recalculate the
        // world-space bounds, then recenter and scale the final presentation.
        model.rotation.set(-0.34, 0.42, -Math.PI / 2 + 0.14);

        const rotatedBounds = new THREE.Box3().setFromObject(model);
        const rotatedCenter = rotatedBounds.getCenter(new THREE.Vector3());
        model.position.sub(rotatedCenter);

        const centeredBounds = new THREE.Box3().setFromObject(model);
        const size = centeredBounds.getSize(new THREE.Vector3());
        const maxDimension = Math.max(size.x, size.y, size.z) || 1;
        const targetSize = 1.48 * modelScale;
        model.scale.setScalar(targetSize / maxDimension);

        scene.add(model);
        controls.target.set(0, 0, 0);
        controls.update();
        setLoaded(true);
      },
      undefined,
      (error) => {
        console.error("Supercharger model failed to load:", src, error);
        if (!disposed) setFailed(true);
      },
    );

    const stopAutoRotate = () => {
      controls.autoRotate = false;
    };
    renderer.domElement.addEventListener("pointerdown", stopAutoRotate, { once: true });

    const resize = () => {
      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();
    requestAnimationFrame(resize);

    const animate = () => {
      if (disposed) return;
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", stopAutoRotate);
      ownedMaterials.forEach((material) => material.dispose());
      renderer.dispose();
      renderer.domElement.remove();
      model?.traverse((child) => {
        if (child instanceof THREE.Mesh) child.geometry?.dispose();
      });
    };
  }, [src, autoRotate, modelScale]);

  return (
    <div
      className={`supercharger-model ${className}`}
      ref={mountRef}
      role="img"
      aria-label={label}
    >
      {!loaded && !failed && <span className="supercharger-status">Loading 3D assembly</span>}
      {failed && <span className="supercharger-status">3D assembly unavailable</span>}
      <span className="supercharger-interaction-hint">Drag to rotate · Scroll to zoom</span>
    </div>
  );
}
