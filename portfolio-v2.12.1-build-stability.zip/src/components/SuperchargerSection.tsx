"use client";

import dynamic from "next/dynamic";
import { motion, useReducedMotion } from "motion/react";
import { useMemo, useState } from "react";
import styles from "./SuperchargerSection.module.css";

const SuperchargerModel = dynamic(
  () => import("./SuperchargerModel").then((module) => module.SuperchargerModel),
  {
    ssr: false,
    loading: () => (
      <div className="supercharger-model" role="status" aria-live="polite">
        <span className="model-status">Loading 3D assembly</span>
      </div>
    ),
  },
);

function getAssemblyState(progress: number) {
  if (progress < 0.08) return "Assembled";
  if (progress < 0.34) return "Housing + rotor pack";
  if (progress < 0.61) return "Timing drive";
  if (progress < 0.84) return "Snout + bearings";
  return "Fully exploded";
}

export function SuperchargerSection() {
  const [explodeProgress, setExplodeProgress] = useState(0);
  const reduceMotion = useReducedMotion();
  const stateLabel = useMemo(() => getAssemblyState(explodeProgress), [explodeProgress]);

  return (
    <section className={styles.section} id="supercharger">
      <div className={`${styles.shell} section-shell`}>
        <motion.div
          className={styles.copy}
          initial={reduceMotion ? false : { opacity: 0, y: 26 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.72, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className={styles.eyebrow}>02 / Mechanical design</p>
          <h2>Roots supercharger</h2>
          <p className={styles.summary}>
            Interactive assembly study with separated housing, rotor, timing-drive, bearing, and snout components.
          </p>
          <div className={styles.meta}>
            <span>Onshape</span>
            <span>Assembly</span>
            <span>2026</span>
          </div>
        </motion.div>

        <motion.div
          className={styles.viewer}
          initial={reduceMotion ? false : { opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.9, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
        >
          <SuperchargerModel explodeProgress={explodeProgress} />
        </motion.div>

        <div className={styles.controls}>
          <div className={styles.controlHeader}>
            <div>
              <span className={styles.controlLabel}>Assembly state</span>
              <strong>{stateLabel}</strong>
            </div>
            <div className={styles.quickActions}>
              <button type="button" onClick={() => setExplodeProgress(0)}>
                Assemble
              </button>
              <button type="button" onClick={() => setExplodeProgress(1)}>
                Explode
              </button>
            </div>
          </div>

          <label className={styles.sliderLabel} htmlFor="supercharger-explode-slider">
            <span>Assembled</span>
            <span>Drag to explode</span>
            <span>Exploded</span>
          </label>
          <input
            id="supercharger-explode-slider"
            className={styles.slider}
            type="range"
            min="0"
            max="100"
            step="1"
            value={Math.round(explodeProgress * 100)}
            onChange={(event) => setExplodeProgress(Number(event.target.value) / 100)}
            aria-label="Supercharger exploded-view progress"
          />

          <div className={styles.sequence} aria-hidden="true">
            <span>Housing</span>
            <span>Rotor pack</span>
            <span>Timing drive</span>
            <span>Snout</span>
          </div>
        </div>
      </div>
    </section>
  );
}
