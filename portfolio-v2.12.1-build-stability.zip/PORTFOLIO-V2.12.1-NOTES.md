# Portfolio V2.12.1 — Build stability hotfix

- Lazily loads the supercharger 3D renderer in a browser-only chunk.
- Enables Next.js Webpack memory optimizations.
- Does not change the model, explosion data, layout, or visual styling.
