"use client";

import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useState } from "react";
import styles from "./AircraftCFDSection.module.css";

type StageId = "research" | "profile" | "geometry" | "mesh";

type Stage = {
  id: StageId;
  number: string;
  label: string;
  title: string;
  description: string;
  image: string;
  alt: string;
  tag: string;
};

const stages: Stage[] = [
  {
    id: "research",
    number: "01",
    label: "Aircraft assumptions",
    title: "First-order sizing",
    description:
      "The study began with a realistic business-jet envelope: 6–8 passengers, dual turbofan propulsion, a 390-knot cruise target, and a 35,000–43,000 ft operating altitude. These assumptions established the aerodynamic and propulsion requirements used later in the design.",
    image: "/images/aircraft/initial-research.webp",
    alt: "Initial aircraft sizing table with NACA 23012 reference airfoil and business jet sketch",
    tag: "Research basis",
  },
  {
    id: "profile",
    number: "02",
    label: "Airfoil selection",
    title: "NACA 23012 reference",
    description:
      "A NACA 23012 profile was selected as the two-dimensional section used for the preprocessing study. The normalized chord definition provided a controlled geometry for comparing the theoretical profile with the imported analysis model.",
    image: "/images/aircraft/naca-23012-profile.webp",
    alt: "NACA 23012 airfoil profile plotted over a normalized chord",
    tag: "12% thickness",
  },
  {
    id: "geometry",
    number: "03",
    label: "Geometry preparation",
    title: "DesignModeler import",
    description:
      "The coordinate-based airfoil was recreated in ANSYS DesignModeler and aligned to the analysis coordinate system. This stage established a clean, closed profile before the external flow domain and boundary definitions were created.",
    image: "/images/aircraft/airfoil-geometry.webp",
    alt: "NACA 23012 airfoil geometry aligned in ANSYS DesignModeler",
    tag: "2D profile",
  },
  {
    id: "mesh",
    number: "04",
    label: "Mesh development",
    title: "Near-wall refinement",
    description:
      "An unstructured triangular domain was refined progressively toward the airfoil. The near-field mesh concentrates elements around the leading edge, trailing edge, and surface boundary so pressure and velocity gradients can be resolved more effectively in Fluent.",
    image: "/images/aircraft/mesh-detail-wide.webp",
    alt: "Refined triangular mesh around the airfoil with a close view of the leading-edge boundary layer",
    tag: "Local refinement",
  },
];

const assumptions = [
  ["Passengers", "6–8"],
  ["Propulsion", "Dual turbofan"],
  ["Liftoff", "107 kt / 55.05 m/s"],
  ["Cruise", "390 kt / 200.6 m/s"],
  ["Altitude", "35,000–43,000 ft"],
  ["Takeoff mass", "≈ 6,000 kg"],
];

export function AircraftCFDSection() {
  const [activeId, setActiveId] = useState<StageId>("research");
  const reduceMotion = useReducedMotion();
  const active = stages.find((stage) => stage.id === activeId) ?? stages[0];

  return (
    <section className={styles.section} id="aircraft-cfd">
      <div className={`${styles.intro} section-shell`}>
        <motion.div
          className={styles.copy}
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.35 }}
          transition={{ duration: reduceMotion ? 0.01 : 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="project-label">03 / Aerodynamic analysis</p>
          <h2>Subsonic aircraft CFD</h2>
          <div className={styles.statement}>
            <span>Concept sizing.</span>
            <span>Airfoil preprocessing.</span>
          </div>
          <p className={styles.summary}>
            A conceptual midsize business jet inspired by the Cessna Citation II Bravo, developed
            through aerodynamic sizing, drag estimation, propulsion analysis, and structural wing
            loading calculations. The project combines fluid-mechanics theory with real aircraft
            data to establish a realistic first-order design for subsonic cruise.
          </p>
          <div className={styles.meta}>
            <span>ANSYS Fluent</span>
            <span>DesignModeler</span>
            <span>MATLAB</span>
          </div>
        </motion.div>

        <motion.figure
          className={styles.heroVisual}
          initial={reduceMotion ? false : { opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: reduceMotion ? 0.01 : 0.95, ease: [0.22, 1, 0.36, 1] }}
        >
          <img
            src="/images/aircraft/mesh-detail-wide.webp"
            alt="Detailed airfoil mesh refinement used during CFD preprocessing"
          />
          <figcaption>
            <span>Preprocessing study</span>
            <span>NACA 23012</span>
          </figcaption>
        </motion.figure>
      </div>

      <div className={`${styles.sequence} section-shell`}>
        <div className={styles.sequenceHeader}>
          <span>Preprocessing sequence</span>
          <span>{active.number} / 04</span>
        </div>

        <div className={styles.stageNav} role="tablist" aria-label="CFD preprocessing stages">
          {stages.map((stage) => (
            <button
              key={stage.id}
              type="button"
              role="tab"
              aria-selected={activeId === stage.id}
              className={activeId === stage.id ? styles.stageActive : undefined}
              onClick={() => setActiveId(stage.id)}
            >
              <span>{stage.number}</span>
              <span>{stage.label}</span>
            </button>
          ))}
        </div>

        <div className={styles.stagePanel}>
          <div className={styles.imageStage}>
            <AnimatePresence mode="wait" initial={false}>
              <motion.img
                key={active.id}
                src={active.image}
                alt={active.alt}
                initial={reduceMotion ? false : { opacity: 0, y: 18, scale: 0.99 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={reduceMotion ? undefined : { opacity: 0, y: -12, scale: 0.995 }}
                transition={{ duration: reduceMotion ? 0.01 : 0.45, ease: [0.22, 1, 0.36, 1] }}
              />
            </AnimatePresence>
            <div className={styles.imageIndex}>
              <span>{active.tag}</span>
              <span>{active.number}</span>
            </div>
          </div>

          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={active.id}
              className={styles.stageCopy}
              initial={reduceMotion ? false : { opacity: 0, x: 18 }}
              animate={{ opacity: 1, x: 0 }}
              exit={reduceMotion ? undefined : { opacity: 0, x: -12 }}
              transition={{ duration: reduceMotion ? 0.01 : 0.42, ease: [0.22, 1, 0.36, 1] }}
            >
              <p>{active.label}</p>
              <h3>{active.title}</h3>
              <p>{active.description}</p>

              {active.id === "research" ? (
                <dl className={styles.assumptions}>
                  {assumptions.map(([label, value]) => (
                    <div key={label}>
                      <dt>{label}</dt>
                      <dd>{value}</dd>
                    </div>
                  ))}
                </dl>
              ) : null}

              {active.id === "mesh" ? (
                <div className={styles.meshPair}>
                  <figure>
                    <img src="/images/aircraft/mesh-domain.webp" alt="Full triangular CFD domain mesh" />
                    <figcaption>Domain mesh</figcaption>
                  </figure>
                  <figure>
                    <img
                      src="/images/aircraft/mesh-boundary-layer.webp"
                      alt="Close view of refined cells at the airfoil leading edge"
                    />
                    <figcaption>Surface refinement</figcaption>
                  </figure>
                </div>
              ) : null}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className={styles.pendingNote}>
          <span>Next phase</span>
          <span>Boundary conditions · Fluent solution · aerodynamic results</span>
        </div>
      </div>
    </section>
  );
}
