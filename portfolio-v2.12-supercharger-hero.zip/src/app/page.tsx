import { ContactFooter } from "@/components/ContactFooter";
import { DesignPractice } from "@/components/DesignPractice";
import { HeroProfile } from "@/components/HeroProfile";
import { Navigation } from "@/components/Navigation";
import { ScrollProgress } from "@/components/ScrollProgress";
import { SelectedWork } from "@/components/SelectedWork";
import { SuperchargerSection } from "@/components/SuperchargerSection";
import { WheelSpotlight } from "@/components/WheelSpotlight";
import { WheelUnifiedViewer } from "@/components/WheelUnifiedViewer";

export default function Home() {
  return (
    <main>
      <ScrollProgress />
      <Navigation />
      <HeroProfile />
      <DesignPractice />
      <SelectedWork />
      <WheelSpotlight />
      <WheelUnifiedViewer />
      <SuperchargerSection />
      <ContactFooter />
    </main>
  );
}
