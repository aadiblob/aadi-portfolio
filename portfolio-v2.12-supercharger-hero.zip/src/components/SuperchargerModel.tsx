"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

type SuperchargerModelProps = {
  explodeProgress: number;
};

type ExplodablePart = {
  object: THREE.Object3D;
  basePosition: THREE.Vector3;
  explodedPosition: THREE.Vector3;
  start: number;
  end: number;
};

function clamp01(value: number) {
  return Math.min(1, Math.max(0, value));
}

function smootherStep(value: number) {
  const t = clamp01(value);
  return t * t * t * (t * (t * 6 - 15) + 10);
}

export function SuperchargerModel({ explodeProgress }: SuperchargerModelProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const explodeRef = useRef(explodeProgress);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    explodeRef.current = explodeProgress;
  }, [explodeProgress]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    setLoaded(false);
    setFailed(false);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);
    camera.position.set(0, 0.04, 2.45);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    mount.appendChild(renderer.domElement);

    const hemisphere = new THREE.HemisphereLight(0xffffff, 0x080808, 1.55);
    scene.add(hemisphere);

    const key = new THREE.DirectionalLight(0xffffff, 4.8);
    key.position.set(3.2, 4.4, 5.6);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0xbfc7d4, 3.1);
    rim.position.set(-4.2, 1.2, -3.3);
    scene.add(rim);

    const fill = new THREE.DirectionalLight(0xffffff, 1.55);
    fill.position.set(0.2, -4.4, 2.5);
    scene.add(fill);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.065;
    controls.enablePan = false;
    controls.enableZoom = true;
    controls.minDistance = 1.35;
    controls.maxDistance = 4.2;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.48;

    let presentationRoot: THREE.Object3D | null = null;
    let assemblyAsset: THREE.Object3D | null = null;
    let assemblyBaseY = 0;
    let parts: ExplodablePart[] = [];
    let frame = 0;
    let disposed = false;

    const enhancedMaterials: THREE.Material[] = [];

    const enhanceMaterial = (material: THREE.Material) => {
      const clone = material.clone();
      enhancedMaterials.push(clone);

      if (clone instanceof THREE.MeshStandardMaterial) {
        const { r, g, b } = clone.color;
        const isGold = r > 0.7 && g > 0.35 && b < 0.2;
        clone.metalness = isGold ? 0.58 : 0.74;
        clone.roughness = isGold ? 0.28 : 0.34;
        clone.envMapIntensity = 1.2;
        clone.side = THREE.DoubleSide;
      }

      return clone;
    };

    const loader = new GLTFLoader();
    loader.load(
      "/models/supercharger/supercharger-assembly.glb",
      (gltf) => {
        if (disposed) return;

        assemblyAsset = gltf.scene;
        const assemblyRoot =
          assemblyAsset.getObjectByName("Supercharger_Assembly") ?? assemblyAsset.children[0];

        assemblyAsset.traverse((child) => {
          if (!(child instanceof THREE.Mesh)) return;

          if (Array.isArray(child.material)) {
            child.material = child.material.map(enhanceMaterial);
          } else {
            child.material = enhanceMaterial(child.material);
          }

          child.castShadow = false;
          child.receiveShadow = false;
        });

        parts = assemblyRoot.children
          .map((object) => {
            const vector = object.userData.explode;
            if (!Array.isArray(vector) || vector.length !== 3) return null;

            const basePosition = object.position.clone();
            const explodedPosition = basePosition
              .clone()
              .add(new THREE.Vector3(vector[0], vector[1], vector[2]));

            return {
              object,
              basePosition,
              explodedPosition,
              start: Number(object.userData.explodeStart ?? 0),
              end: Number(object.userData.explodeEnd ?? 1),
            } satisfies ExplodablePart;
          })
          .filter((part): part is ExplodablePart => part !== null);

        const assembledBounds = new THREE.Box3().setFromObject(assemblyAsset);
        const assembledCenter = assembledBounds.getCenter(new THREE.Vector3());
        assemblyAsset.position.sub(assembledCenter);
        assemblyBaseY = assemblyAsset.position.y;

        presentationRoot = new THREE.Group();
        presentationRoot.add(assemblyAsset);
        presentationRoot.rotation.set(-0.34, 0.42, -Math.PI / 2 + 0.14);

        const rotatedBounds = new THREE.Box3().setFromObject(presentationRoot);
        const rotatedCenter = rotatedBounds.getCenter(new THREE.Vector3());
        presentationRoot.position.sub(rotatedCenter);

        const size = rotatedBounds.getSize(new THREE.Vector3());
        const maxDimension = Math.max(size.x, size.y, size.z) || 1;
        presentationRoot.scale.setScalar(1.42 / maxDimension);

        scene.add(presentationRoot);
        controls.target.set(0, 0, 0);
        controls.update();
        setLoaded(true);
      },
      undefined,
      (error) => {
        console.error("Supercharger model failed to load:", error);
        if (!disposed) setFailed(true);
      },
    );

    const stopAutoRotate = () => {
      controls.autoRotate = false;
    };
    renderer.domElement.addEventListener("pointerdown", stopAutoRotate, { once: true });

    const resize = () => {
      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();
    requestAnimationFrame(resize);

    const animate = () => {
      if (disposed) return;
      frame = requestAnimationFrame(animate);

      const progress = clamp01(explodeRef.current);
      parts.forEach((part) => {
        const localProgress = smootherStep((progress - part.start) / Math.max(0.001, part.end - part.start));
        part.object.position.lerpVectors(part.basePosition, part.explodedPosition, localProgress);
      });

      if (assemblyAsset) {
        assemblyAsset.position.y = assemblyBaseY - smootherStep(progress) * 0.085;
      }

      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", stopAutoRotate);
      enhancedMaterials.forEach((material) => material.dispose());
      presentationRoot?.traverse((child) => {
        if (child instanceof THREE.Mesh) child.geometry?.dispose();
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div
      className="supercharger-model"
      ref={mountRef}
      role="img"
      aria-label="Interactive Roots supercharger assembly with exploded-view control"
    >
      {!loaded && !failed && <span className="model-status">Loading 3D assembly</span>}
      {failed && <span className="model-status">3D assembly unavailable</span>}
      <span className="supercharger-interaction-hint">Drag to rotate · Scroll to zoom</span>
    </div>
  );
}
