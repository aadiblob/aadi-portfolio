# Portfolio V2.12 — Supercharger Hero + Exploded Assembly

## Added
- Interactive Roots supercharger hero section
- 360-degree drag rotation and scroll zoom
- Slow automatic rotation until the model is grabbed
- Assembled-to-exploded range slider
- Sequential component animation based on the supplied exploded-view reference
- Quick Assemble and Explode buttons
- Selected Work link now jumps directly to the supercharger section

## Model preparation
The uploaded GLB was preserved as one assembly and enriched with:
- Unique component names
- Explosion vectors
- Sequential animation timing metadata

No CFD imagery or dimensional claims were added in this pass.
